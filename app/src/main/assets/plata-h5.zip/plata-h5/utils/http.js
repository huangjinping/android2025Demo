import { getUrlParams } from './href';

const TEST_URL = 'https://temp.prestamogratis.com/platapuntual';
const defaultHeaders = {
  ashamedDumplingUnknownLiquidBeehive: 466,
  publicNonBarbecueEagerActress: 'googleplay',
  passiveGardening: '1.0.0',
  manyVillageInternationalPlayroom: '100',
  britishGallonNearRainfallEverything: 'deviceId',
  africanFancyGunDisability: 'imei',
  dullRepairsHonestSoup: 'device-id',
  upperSouthMicroscopeInventor: 1,
  luckySuccessfulTwinFriendship: true,
  strongNurseInstantScissorsQuickSkirt: 'applicationId',
  slimSoftballMessySmokingLie: 'configAppSsid',
};

export const request = async (url, data = {}, method = 'POST', header = {}) => {
  const userInfo = getUserInfo();
  const defaultParams = {
    eastGodSharpGiftValuableGate: 466,
    merryFollowingMiddle: userInfo.userId,
    bothDifficultyReadyChickCastle: '0.0',
    possibleLaughter: 'es',
    passiveGardening: defaultHeaders.passiveGardening,
    manyVillageInternationalPlayroom: defaultHeaders.manyVillageInternationalPlayroom,
    cottonEuropeanZipperGoldenBelief: defaultHeaders.britishGallonNearRainfallEverything,
    africanFancyGunDisability: defaultHeaders.africanFancyGunDisability,
    longPeaArrival: '0.0.0.0',
    publicNonBarbecueEagerActress: defaultHeaders.publicNonBarbecueEagerActress,
    splendidImmediateSunsetInterpreter: '1',
    stupidTinySteelCountry: '1',
    indeedBarButterClub: 'web',
    sparePracticalDocumentMistakenBasement: 466,
  };

  let formData = new FormData();

  for (let key in { ...defaultParams, ...data }) {
    formData.append(key, data[key]);
  }
  console.log('formData', formData);
  return new Promise(async (resolve, reject) => {
    uni.showLoading({
      mask: true,
    });
    uni.request({
      url: '/api' + url,
      header: {
        ...defaultHeaders,
        humanDisabledPoliticsScotland: userInfo.token,
        merryFollowingMiddle: userInfo.userId,
        naturalSpanishGoldfish: userInfo.userId,
        ...header,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      method,
      data: { ...defaultParams, ...data },

      success(res) {
        const {
          scientificFoolEasternEssayPrimaryPuzzle: code,
          secondAsianLightningFlatArticle: data,
          fairHawkHelicopterMailbox: msg,
        } = res.data;
        if (code === 1000) {
          resolve(data);
          return;
        }

        if (code === -1001) {
          // TODO 跳转登录
        } else {
          uni.showToast({
            title: msg || 'Error',
            icon: 'error',
            mask: true,
          });
        }
        reject();
      },
      fail(err) {
        reject(err);
      },
      complete() {
        uni.hideLoading();
      },
    });
  });
};

export const getUserInfo = () => ({
  token: '9b175308-7e07-4d90-94ad-494b3485a7a2',
  userId: '19162',
  testCustFlag: '1', // 1为测试账号
});
