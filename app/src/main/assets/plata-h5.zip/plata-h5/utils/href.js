/**
 * 获取链接参数
 * @param {*} url
 * @returns
 */
const getUrlParams = (url = window.location.href) => {
  const params = {};
  const paramString = url.split('?')[1];
  if (paramString) {
    const paramPairs = paramString.split('&');
    paramPairs.forEach((pair) => {
      const [key, value] = pair.split('=');
      params[key] = decodeURIComponent(value);
    });
  }
  return params;
};
