<template>
  <view class="order-status-page">
    <status-bar
      v-show="hasStatusBar"
      :isScroll="isScroll"
      title="EfectivoExpress"
      hasService
    ></status-bar>
    <view class="top" :style="{ paddingTop: `${statusBarHeight}px` }">
      <view class="loan-wrapper">
        <!-- 放款失败 -->
        <text v-if="status === 4" class="rejected">Depósito fallido</text>
        <!-- 拒绝 -->
        <text v-if="status === 3" class="rejected">Préstamo rechazado</text>
        <!-- 放款中 -->
        <text v-if="status === 5" class="rejected" style="color: #fff">Desembolsando préstamo</text>
        <!-- 等待审核 -->
        <text v-if="status === 6" class="rejected" style="color: #fff">Bajo revisión</text>

        <!-- 拒绝的时候不显示以下 -->
        <view class="loan-info" v-if="status && status !== 3">
          <text class="info-title">Fecha de solicitud</text>
          <text class="date">{{ orderDetail.submitTime }}</text>
          <text class="money-label">Monto del préstamo</text>
          <text class="money">$ {{ orderDetail.applyAmt }}</text>
        </view>
      </view>
    </view>
    <!-- 拒绝 -->
    <view v-if="status === 3" class="rejected-wrapper">
      <view class="rejected-top">
        <image class="rejected-icon" src="/static/order-rejected-icon.png" />
        <text class="title">Perdón</text>
      </view>
      <view class="content-wrapper">
        <text class="content">
          La razón del rechazo puede ser: -Sus informaciones proporcionadas no son correctas -Su
          foto de reconocimiento facial no es válida -Sus informaciones necesitan ser revisado más
          profundamente
        </text>
      </view>
      <text class="rejected-msg">
        La próxima fecha de disponibilidad del préstamo es
        <text style="font-weight: bold; padding-left: 6px">{{
          orderDetail.reapplicationDate
        }}</text>
      </text>
    </view>
    <!-- 放款失败 -->
    <view v-if="status === 4" class="remit-rejected-content">
      <view class="remit-rejected-btn">
        <text>Actualizar cuenta receptora</text>
      </view>
      <view class="rejected-wrapper">
        <view class="rejected-top">
          <image class="rejected-icon" src="/static/order-rejected-icon.png" />
          <text class="title">Perdón</text>
        </view>
        <view class="content-wrapper">
          <text class="content">
            El sistema ha detectado que las informaciones de su cuenta no son correctas,por favor
            las completa de nuevo
          </text>
        </view>
      </view>
    </view>

    <!-- 等待审核 -->
    <view v-if="status === 6" class="pending-review">
      <text>
        Estamos evaluando su crédito,por favor presta atención a comprobar el resultado de la solicitud
      </text>
    </view>

    <!-- 放款中 -->
    <view v-if="status === 5" class="loan-in-progress">
      <view class="msg-wrapper">
        <image class="icon" src="/static/loan-in-progress-icon.png" />
        <text class="text"
          >Su solicitud ha sido aprobado.Se está desembolsando su préstamo.Por favor espera
          pacientemente.</text
        >
      </view>
      <view class="text-wrapper"
        ><text class="text">
          Su préstamo está en proceso de desembolso: en días laborables, se espera que llegue en 48
          horas. En días festivos, se espera que llegue el siguiente día laborable. Te informaremos
          por SMS cuando tu préstamo haya llegado y actualizaremos el estado en la aplicación. Si el
          préstamo no ha llegado pasadas 48 horas, póngase en contacto con nuestro servicio de
          atención al cliente.
        </text></view
      >
    </view>

    <text class="agreement">
      Por favor revisa el
      <text style="color: #27886d; margin-left: 6px"> &lt;Aviso de privacidad&gt;</text>
    </text>
  </view>
</template>

<script>
import StatusBar from '../../components/StatusBar/index.vue';
export default {
  data() {
    return {
      isScroll: false,
      hasStatusBar: false,
      orderId: undefined,
      orderDetail: {},
    };
  },
  computed: {
    statusBarHeight() {
      return 44;
    },
    // 0 = 还款 1 = 逾期 3 = 拒绝  4 = 失败 5 = 放款中 6 = 审核中
    status() {
      if (!this.orderDetail) return;
      const { overdueStatus, loanStatus } = this.orderDetail;
      if ([0, 1, 3].includes(overdueStatus)) return overdueStatus;
      if (overdueStatus === 2) {
        if (loanStatus === 2) return 4;
        if (loanStatus === 3) return 5;
        return 6;
      }
      return undefined;
    },
  },
  components: { StatusBar },
  methods: {
    transferData(data) {
      const map = {
        bothAdvantageForeignShowBothNationality: 'repayAmountPart',
        unfitCorrectionBeautifulStomachache: 'partRepayFlag',
        unfortunateSurePaddleSquareVeal: 'reapplicationDate',
        stupidSecretaryKilometreDance: 'reapplicationDays',
        snowyFirefighterPoliticalItalianPrinter: 'complianceIgvAndServiceFee',
        farDistrictHelpfulDollar: 'reborrowFlag',
        paleChurch: 'overdueStatus',
        averageJunkActualDirectorySauce: 'creditAmount',
        rudeBoatNationalCropAddition: 'firstLoanReject',
        messyRefusal: 'orderId',
        moralCrossingSilkBalance: 'orderNo',
        properZooFirmAnxiousTape: 'intAmount',
        sharpArabCameraChat: 'duration',
        quietMomCertainChairman: 'extendDuration',
        practicalFirefighterThisMovement: 'desc',
        instantJustPromise: 'loanStatus',
        britishBrightPassiveCrossroads: 'approveStatus',
        coolRainySatelliteEnemy: 'approvalStatusDesc',
        steadySmallHim: 'repayAmt',
        looseGrandPrimaryDryer: 'iva',
        roundaboutPerfectCleverCartoon: 'repayFlag',
        antarcticSwitzerlandBeehive: 'applyDate',
        clearFullTin: 'repaymentDate',
        constantModestPossession: 'lateFee',
        electricAdvertisement: 'deductionFee',
        hugeSheepProbableCorner: 'overdueDays',
        familiarChartMaleDrink: 'mprepayFee',
        coolMotorcycleMountainousPurpose: 'offlineRepayCode',
        someFailureExpression: 'extendFlag',
        dailyTramSocialistMotorbike: 'dayLateFee',
        suddenMaximumShoe: 'loanFinish',
        lateAdditionBusyTraveler: 'firstLoanFinish',
        arabicReceptionistBlueBalloonPartIceland: 'applyAmt',
        brokenAffairPeriodPuzzledEquality: 'submitTime',
        foolishMarriedDiplomaFollowingTroop: 'payToken',
        nonHistoryMoon: 'earlyRepayDesc',
        quietMomCertainChairman: 'extendDuration',
        lemonKilometreFrequentFaultHillyBlackboard: 'repayActionPLFlag',
        goldenTractorJewelryBottle: 'apr',
        thirstyShelfRegards: 'expectApplyAmt',
        bornSkyscraperThemBasicValue: 'expectApplyDuration',
        likelyRecordAbilityExpert: 'nextPageType',
        ableTheoreticalAtmosphereGladSchoolbag: 'firstPageType',
        politePartyStringChest: 'preApprovalStatusViewStatus',
        partBaconSoccer: 'settleStatus',
        immediateClinicSpecialResult: 'flexobleRepayFlag',
        everydayBicycleUnimportantGlobeHive: 'flexibleRepaymentAmount',
        freeSimilarTuesday: 'flexibleRepaymentMinAmount',
        badStringShabbyBarNeedle: 'epFailedMessage',
        sleepySubjectSharpBicycleFortunateHat: 'epFailedMessage1',
        heavyThinPianoNecessaryLady: 'epFailedMessage2',
        forgetfulLeftExitFrance: 'epUrlMessage',
        sleepyArcticFacialLiterature: 'epUrl',
      };
      for (const key in map) {
        this.$set(this.orderDetail, map[key], data[key]);
      }
      console.log('this.orderDetail', this.orderDetail);
    },
    async handleGetData() {
      try {
        const result = await this.$request(
          '/businesswoman/regardSleepySharpener',
          this.orderId
            ? {
                messyRefusal: this.orderId,
              }
            : {}
        );
        this.transferData(result);
      } catch (e) {
        console.log(e);
      }
    },
  },
  onLoad(e) {
    this.hasStatusBar = !!e?.hasStatusBar;
    this.orderId = e?.orderId;
  },
  mounted() {
    this.handleGetData();
  },
  onPageScroll(e) {
    this.isScroll = e.scrollTop > this.statusBarHeight;
  },
};
</script>

<style scoped lang="scss">
.order-status-page {
  box-sizing: border-box;
  position: relative;
  width: 100%;
  min-height: 100vh;
  background: #f2f2f2;
  display: flex;
  flex-direction: column;
  padding-bottom: 80px;
  .top {
    box-sizing: border-box;
    padding-bottom: 33px;
    width: 100%;
    min-height: 113px;
    background: #24443b;
    margin-bottom: 20px;

    .rejected {
      display: block;
      padding-top: 7px;
      text-align: center;
      font-size: 18px;
      line-height: 21px;
      color: #ff5050;
      font-weight: bold;
    }
    .loan-wrapper {
      box-sizing: border-box;
      padding: 0 27px;
      width: 100%;
      display: flex;
      flex-direction: column;

      .loan-info {
        padding: 27px 0;
        display: flex;
        flex-direction: column;
        width: 100%;
        align-items: center;
        justify-content: center;
        width: 100%;
        border-radius: 8px;
        background: #fff;
        margin-top: 13px;
        .info-title {
          font-size: 15px;
          color: #333;
          margin-bottom: 10px;
          line-height: 17px;
        }
        .date {
          font-weight: bold;
          color: #333;
          font-size: 25px;
          line-height: 28px;
          margin-bottom: 23px;
        }
        .money-label {
          font-size: 15px;
          line-height: 17px;
          color: #333;
          margin-bottom: 10px;
        }
        .money {
          font-size: 18px;
          color: #333;
          font-weight: bold;
          line-height: 20px;
        }
      }
    }
  }
  .rejected-wrapper {
    box-sizing: border-box;
    padding: 14px 20px 20px;
    background: #fff;
    .rejected-top {
      display: flex;
      flex-direction: row;
      align-items: center;
      gap: 10px;
      .rejected-icon {
        width: 43px;
        height: 43px;
      }
      .title {
        color: #16271e;
        font-size: 18px;
        line-height: 21px;
        font-weight: bold;
      }
    }
    .content-wrapper {
      padding-bottom: 16px;
      border-bottom: 1px dashed #979797;
      .content {
        color: #666666;
        font-size: 15px;
        line-height: 17px;
      }
    }

    .rejected-msg {
      display: block;
      padding-top: 14px;
      font-size: 14px;
      line-height: 20px;
      color: #cf4a4a;
    }
  }
  .remit-rejected-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-top: 28px;
    gap: 30px;
    .remit-rejected-btn {
      width: 291px;
      height: 50px;
      line-height: 50px;
      text-align: center;
      background: #1d3e35;
      border: 1px solid #74f461;
      border-radius: 4px;
      font-size: 18px;
      font-weight: bold;
      color: #fff;
    }
    .content-wrapper {
      border: none !important;
    }
  }
  .pending-review {
    box-sizing: border-box;
    padding: 22px 35px 18px 32px;
    font-size: 15px;
    line-height: 17px;
    color: #666;
    background: #fff;
  }
  .loan-in-progress {
    display: flex;
    flex-direction: column;
    gap: 20px;
    width: 100%;
    .text {
      font-size: 15px;
      line-height: 17px;
      color: #666666;
    }
    .msg-wrapper {
      display: flex;
      flex-direction: row;
      gap: 13px;
      justify-content: center;
      box-sizing: border-box;
      padding: 11px 20px;
      background: #fff;
      .icon {
        width: 64px;
        height: 64px;
      }
      .text {
        flex: 1;
      }
    }
    .text-wrapper {
      box-sizing: border-box;
      padding: 18px 20px 20px 20px;
      background: #fff;
    }
  }
  .agreement {
    position: absolute;
    width: 100%;
    bottom: 24px;
    font-size: 15px;
    color: #333;
    text-align: center;
  }
}
</style>
