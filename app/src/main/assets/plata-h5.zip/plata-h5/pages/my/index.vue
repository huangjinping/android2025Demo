<template>
  <view class="my-page-wrapper">
    <view class="top"></view>
    <view class="user-info">
      <text class="title"> PrestaYa </text>
      <image class="avatar" />
      <text class="name">Plata Puntual</text>
      <text class="phone">+593 954-566670</text>
    </view>
    <view class="list">
      <view class="item">
        <image class="icon" src="/static/my-config.png"></image>
        <text class="value">Configuración</text>
        <image class="arrow" src="/static/my-arrow.png"></image>
      </view>
      <view class="item">
        <image class="icon" src="/static/my-contact.png"></image>
        <text class="value">Contactar con servicio de atención al cliente</text>
        <image class="arrow" src="/static/my-arrow.png"></image>
      </view>
      <view class="item">
        <image class="icon" src="/static/my-privacy.png"></image>
        <text class="value">Aviso de privacidad</text>
        <image class="arrow" src="/static/my-arrow.png"></image>
      </view>
      <view class="item">
        <image class="icon" src="/static/my-info.png"></image>
        <text class="value">Información personal</text>
        <image class="arrow" src="/static/my-arrow.png"></image>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {};
  },
  onLoad() {},
  methods: {},
};
</script>

<style scoped lang="scss">
.my-page-wrapper {
  display: flex;
  flex-direction: column;
  .top {
    width: 100%;
    height: 150px;
    background: #1d3e35;
  }
  .user-info {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: -25%;
    margin-bottom: 30px;
    .title {
      font-size: 15px;
      color: #fff;
      line-height: 17px;
      margin-bottom: 13px;
    }
    .avatar {
      width: 112px;
      height: 112px;
      background: #fff;
      border-radius: 50%;
      box-shadow: 0px 2px 13px 0px rgba(29, 62, 53, 0.21);
      margin-bottom: 20px;
    }
    .name {
      font-size: 20px;
      line-height: 23px;
      font-weight: bold;
      color: #333333;
      margin-bottom: 14px;
    }
    .phone {
      font-size: 15px;
      line-height: 17px;
      color: #333333;
    }
  }
  .list {
    box-sizing: border-box;
    padding: 0 20px 40px 20px;
    display: flex;
    flex-direction: column;
    gap: 16px;
    .item {
      display: flex;
      align-items: center;
      width: 100%;
      height: 52px;
      padding: 0 22px 0 20px;
      box-sizing: border-box;
      border: 1px solid #dbdbdb;
      border-radius: 8px;
      background: #f2f2f2;
      gap: 10px;
      .icon {
        width: 34px;
        height: 34px;
      }
      .value {
        flex: 1;
        font-size: 15px;
        color: #333333;
      }
      .arrow {
        width: 11px;
        height: 22px;
      }
    }
  }
}
</style>
