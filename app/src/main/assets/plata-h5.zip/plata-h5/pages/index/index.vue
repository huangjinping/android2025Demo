<template>
  <view class="content">
    <view class="top-info">
      <view class="top">
        <text class="title">Plata Puntual</text>
        <image class="service" src="/static/service-icon.png" />
      </view>
      <view class="container">
        <view class="content">
          <text class="title">Importe máximo</text>
          <text class="money">{{ money || '&nbsp;' }}</text>
          <view class="day">
            <image class="icon" src="/static/day-icon.png" />
            <text class="label">Plazo del préstamo</text>
            <text v-show="day" class="value">{{ day }} días</text>
          </view>
        </view>
        <view class="tips">
          <text class="msg"
            >Se admite pagar en
            <text class="bold"> 3-6 cuotas</text>
            .El plazo será más largo y flexible</text
          >
        </view>
      </view>
    </view>
    <view class="pay" @click="handleApply">
      <text>Aplica ya</text>
    </view>
    <text class="agreement">
      Por favor revisa el
      <text style="color: #27886d; margin-left: 6px"> &lt;Aviso de privacidad&gt;</text>
    </text>
    <view class="bottom">
      <text class="bottom-title">Consejos</text>
      <view class="info">
        <text class="text">
          <text> Cuanto más veces pidas préstamos,</text>
          más alto será el límite de crédito, más largo será elplazo y la tasa es tan baja como el
          <text style="font-weight: bold; color: #259782; margin-left: 6px">12%</text>.
        </text>
      </view>
      <text class="bottom-title" style="margin-bottom: 19px">Características del producto.</text>
      <view class="list-item">
        <image class="icon" src="/static/home-1.png" />
        <text class="value">Solo 3 pasos</text>
      </view>
      <view class="list-item">
        <image class="icon" src="/static/home-2.png" />
        <text class="value">90% de éxito</text>
      </view>
      <view class="list-item">
        <image class="icon" src="/static/home-3.png" />
        <text class="value">Procesamiento rápido</text>
      </view>
      <image class="banner" src="/static/home-4.png" />
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      result: {},
    };
  },
  onLoad() {
    this.handleGetData();
  },
  computed: {
    isTest() {
      // TODO 校验客户端参数
      return true;
    },
    money() {
      const { foreignPossibilityHarmfulSecondAirplane, gayAsiaSaleRequest } = this.result;
      return this.isTest ? gayAsiaSaleRequest : foreignPossibilityHarmfulSecondAirplane;
    },
    day() {
      const { excellentPrintingPollution, entirePollutionBadJacketSmoothBlanket } = this.result;
      return this.isTest ? entirePollutionBadJacketSmoothBlanket : excellentPrintingPollution;
    },
  },

  methods: {
    handleApply() {
      uni.navigateTo({
        url: '/pages/applyLoan/index?hasStatusBar=true',
      });
    },
    async handleGetData() {
      try {
        const result = await this.$request('/businesswoman/loseForgetfulMud', {
          practicalSpeechSunset:
            'foreignPossibilityHarmfulSecondAirplane,gayAsiaSaleRequest,excellentPrintingPollution,entirePollutionBadJacketSmoothBlanket',
        });
        this.result = result;
      } catch (e) {
        console.log(e);
      }
    },
  },
};
</script>

<style scoped lang="scss">
.content {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  .top-info {
    padding-bottom: 21px;
    display: flex;
    flex-direction: column;
    background-color: #24443b;
    width: 100%;
    margin-bottom: 22px;
    .top {
      display: flex;
      padding: 0 20px;
      height: 44px;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 8px;
      .title {
        font-size: 15px;
        color: #fff;
      }
      .service {
        width: 22px;
        height: 18px;
      }
    }
    .container {
      box-sizing: border-box;
      padding: 0 20px;
      .content {
        box-sizing: border-box;
        display: flex;
        flex-direction: column;
        width: 100%;
        border-radius: 8px;
        background: #fff;
        padding: 14px 10px 6px;
        align-items: start;
        margin-bottom: 10px;
        .title {
          font-size: 18px;
          color: rgba($color: #333, $alpha: 0.43);
          margin-bottom: 7px;
        }
        .money {
          display: block;
          width: 100%;
          font-weight: bold;
          font-size: 30px;
          color: #333333;
          padding-bottom: 9px;
          border-bottom: 1px dashed #979797;
        }
        .day {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 18px 0;
          .icon {
            width: 30px;
            height: 22px;
          }
          .label {
            font-size: 15px;
            color: rgba($color: #333, $alpha: 0.5);
          }
          .value {
            font-size: 18px;
            color: #333;
            font-weight: bold;
          }
        }
      }
      .tips {
        width: 100%;
        box-sizing: border-box;
        padding: 11px 24px 19px 20px;
        border-radius: 8px;
        background: #edffea;
        .msg {
          font-size: 14px;
          color: #333333;
          word-break: normal;
          .bold {
            font-weight: bold;
            color: #e02020;
            margin-left: 6px;
          }
        }
      }
    }
  }
  .pay {
    width: 291px;
    height: 50px;
    line-height: 50px;
    text-align: center;
    background: #1d3e35;
    border: 1px solid #74f461;
    border-radius: 4px;
    font-size: 18px;
    font-weight: bold;
    color: #fff;
    margin-bottom: 8px;
  }
  .agreement {
    font-size: 15px;
    color: #333;
    margin-bottom: 20px;
  }
  .bottom {
    box-sizing: border-box;
    width: 100%;
    background: #fff;
    padding: 20px 15px 30px;
    .bottom-title {
      display: block;
      padding-left: 6px;
      color: #333333;
      font-weight: bold;
      font-size: 18px;
      margin-bottom: 10px;
    }
    .info {
      box-sizing: border-box;
      padding: 12px 46px 12px 16px;
      background: url(/static/home-bottom-bg.png) no-repeat;
      background-size: 100% 100%;
      margin-bottom: 20px;
      .text {
        font-size: 15px;
        line-height: 20px;
      }
    }
    .list-item {
      display: flex;
      align-items: center;
      width: 100%;
      height: 52px;
      padding-left: 20px;
      box-sizing: border-box;
      border: 1px solid #dbdbdb;
      border-radius: 8px;
      background: #f2f2f2;
      gap: 10px;
      margin-bottom: 20px;
      .icon {
        width: 34px;
        height: 34px;
      }
      .value {
        font-size: 15px;
        color: #333333;
      }
    }
    .banner {
      width: 100%;
      height: 130px;
    }
  }
}
</style>
