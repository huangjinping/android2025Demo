<template>
  <view
    class="apply-loan-wrapper"
    :style="`${showSelectMoneyModal ? 'overflow: hidden;height:100vh' : ''}`"
  >
    <status-bar
      v-show="hasStatusBar"
      :isScroll="isScroll"
      hasBack
      hasService
      title="EfectivoExpress"
    />
    <view class="top-card" :style="{ paddingTop: `${statusBarHeight}px` }">
      <view class="card-container">
        <view
          class="select-money-wrapper"
          :style="{
            zIndex: showSelectMoneyModal ? '100' : '1',
          }"
          @click="showSelectMoneyModal = !showSelectMoneyModal"
        >
          <text class="label">Seleccionar el préstamo</text>
          <view class="select-money">
            <text class="money">$ {{ selectMoney }}</text>
            <image class="select-money-icon" src="/static/my-arrow.png"></image>
            <view class="select-money-modal" v-show="showSelectMoneyModal">
              <!-- 单项金额 -->
              <view
                class="only"
                @click="
                  () => {
                    handleSelectMoneyChange(0);
                  }
                "
                v-if="moneyList.length === 1"
              >
                <text class="money">$ {{ moneyList[0] }} </text>
              </view>
              <!-- 多项 -->
              <view v-else class="money-picker-view-wrapper">
                <picker-view
                  :value="selectMoneyList"
                  @change="
                    (e) => {
                      handleSelectMoneyChange(e.detail.value[0]);
                    }
                  "
                  indicator-class="money-picker-indicator"
                  class="money-picker-view"
                  mask-style="display:none"
                >
                  <picker-view-column style="padding: 0 !important">
                    <view
                      :class="{
                        'money-picker-item': true,
                        active: index === selectMoneyList[0],
                      }"
                      v-for="(item, index) in moneyList"
                      :key="index"
                      >{{ item }}</view
                    >
                  </picker-view-column>
                </picker-view>
                <view class="bottom-mask"> </view>
              </view>
            </view>
          </view>
        </view>
        <view class="next-loan-wrapper">
          <text class="text">
            Después de la solicitud de hoy, el monto máximo del próximo préstamo será de
            <text class="bold" style="margin-left: 6px">{{ tipsData.maxApplyAmt }}</text
            >, con un plazo máximo de
            <text class="bold" style="margin: 0 6px">{{ tipsData.maxApplyDuration }}</text>
            <text
              >días y un gasto de servicio mínimo de
              <text style="margin-left: 6px" class="bold">{{ tipsData.minServiceFee }}</text
              >.</text
            >
          </text>
          <image class="image" src="/static/next-loan-icon.png"></image>
        </view>
      </view>
    </view>
    <view class="apply-loan-container">
      <view class="select-periods-wrapper">
        <text class="title">Por favor selecciona el plazo de préstamo</text>
        <view class="periods-list">
          <view
            class="periods-item"
            :class="{
              active: currentPeriodsDetailId === item.detailId,
              disabled: item.disabled,
            }"
            v-for="item in periodsList"
            :key="item.detailId"
            @click="handleSelectPeriods(item)"
          >
            <!-- 禁止选择 -->
            <image
              v-if="item.disabled"
              class="periods-disabled-icon"
              src="/static/periods-disabled-icon.png"
            />
            <!-- 单期 -->
            <text v-if="+item.periodDuration === 1" class="day">{{ item.duration }} días</text>
            <!-- 多期 -->
            <view v-else class="multi">
              <text class="period">{{ item.periodDuration }} cuotas</text>
              <text class="day">({{ +item.duration * +item.periodDuration }} días)</text>
            </view>
          </view>
        </view>
        <!-- 多期提示 -->
        <view class="multi-tip" v-if="resultMapPlanList.length > 1">
          <text class="text"
            >El pago mínimo es
            <text class="bold">${{ resultMapPlanList[0].repayAmount }}</text> cada cuota</text
          >
        </view>
      </view>
      <!-- 期数 -->
      <view class="plan-wrapper" v-if="resultMapPlanList.length">
        <!-- 这一层才是v-show的 -->
        <view class="plan-container">
          <text v-if="resultMapPlanList.length === 1" class="title">Plan de pago</text>
          <text v-else class="title">Plan de pago en cuotas</text>
          <!-- 单期 -->
          <view v-if="resultMapPlanList.length === 1" class="one">
            <view class="list" v-for="item in resultMapPlanList" :key="item.repayDate">
              <view class="item">
                <text class="label"><rich-text :nodes="item.titleAmount" /></text>
                <text class="value">$ {{ item.repayAmount }}</text>
              </view>
              <view class="item">
                <text class="label"><rich-text :nodes="item.titleDate" /></text>
                <text class="value">{{ item.repayDate }}</text>
              </view>
            </view>
          </view>
          <!-- 多期 -->
          <view v-else class="multi-list">
            <view v-for="item in resultMapPlanList" :key="item.repayDate" class="list-item">
              <view class="top">
                <image class="icon" src="/static/multi-periods-icon.png"></image>
                <text class="step">{{ item.curDuration }}/{{ installmentData.totalPeriod }}</text>
              </view>
              <view class="list">
                <view class="item">
                  <text class="label"><rich-text :nodes="item.titleAmount" /></text>
                  <text class="value">$ {{ item.repayAmount }}</text>
                </view>
                <view class="item">
                  <text class="label"><rich-text :nodes="item.titleDate" /></text>
                  <text class="value">{{ item.repayDate }}</text>
                </view>
              </view>
            </view>
          </view>
        </view>
      </view>
      <!-- 详情 -->
      <view class="periods-detail" v-if="periodsDetailList.length">
        <view class="periods-detail-title">
          <text>Detalles del préstamo</text>
        </view>
        <view class="list">
          <view
            :class="['item', { bold: item.isBold }]"
            v-for="item in periodsDetailList"
            :key="item.label"
          >
            <text class="label">{{ item.label }}</text>
            <text class="value">{{ item.value }}</text>
          </view>
        </view>
      </view>
      <!-- 申请 -->
      <view class="apply-wrapper">
        <view class="btn">
          <view class="btn-wrapper" @click="handleApply">
            <text class="btn-text">Solicitar el préstamo </text>
          </view>
          <!-- 申请提示 -->
          <view class="tips">
            <text class="text"> Tasa de aprobación será</text>
            <text class="text bold">99%</text>
            <text class="text">si solicita dentro de</text>
            <text class="text bold">15:00</text>
            <view class="triangle"></view>
          </view>
        </view>
        <view class="agreement">
          <view class="checkbox" @click="isCheckAgreement = !isCheckAgreement">
            <image
              v-if="isCheckAgreement"
              class="checkbox"
              src="/static/checkbox-active-icon.png"
            ></image>
            <image v-else class="checkbox" src="/static/checkbox-icon.png"></image>
          </view>
          <view class="text">
            <text class="text">He revisado atentamente el</text>
            <text
              @click="handleClickHref(item)"
              class="link"
              v-for="(item, index) in agreementList"
              :key="item.label"
            >
              &lt;{{ item.label }}&gt;{{ index !== agreementList.length - 1 ? ' y ' : '' }}
            </text>
          </view>
        </view>
      </view>
    </view>
    <view
      class="mask"
      @click="showSelectMoneyModal = !showSelectMoneyModal"
      v-show="showSelectMoneyModal"
    ></view>
    <uni-popup ref="popup" type="center">
      <view class="apply-loan-modal">
        <view class="apply-loan-modal-content">
          <view class="info">
            <view class="list">
              <view class="item">
                <text class="label">Monto del préstamo </text>
                <text class="value">$ {{ installmentData.serverApplyAmount }}</text>
              </view>
              <view class="item">
                <text class="label">Monto recibido</text>
                <text class="value">$ {{ installmentData.disbursalAmount }}</text>
              </view>
            </view>
          </view>
          <view class="periods-wrapper" v-if="resultMapPlanList.length">
            <text v-if="resultMapPlanList.length === 1" class="title">Plan de pago</text>
            <text v-else class="title">Plan de pago en cuotas</text>
            <view v-if="resultMapPlanList.length === 1" class="only">
              <view class="list" v-for="item in resultMapPlanList" :key="item.repayDate">
                <view class="item">
                  <text class="label"><rich-text :nodes="item.titleAmount" /></text>
                  <text class="value">$ {{ item.repayAmount }}</text>
                </view>
                <view class="item">
                  <text class="label"><rich-text :nodes="item.titleDate" /></text>
                  <text class="value">{{ item.repayDate }}</text>
                </view>
              </view>
            </view>
            <view v-else class="multi">
              <view class="multi-item" v-for="item in resultMapPlanList" :key="item.repayDate">
                <view class="multi-item-top">
                  <image class="icon" src="/static/multi-periods-icon.png" />
                  <text class="text">{{ item.curDuration }}/{{ installmentData.totalPeriod }}</text>
                </view>
                <view class="list">
                  <view class="item">
                    <text class="label"><rich-text :nodes="item.titleAmount" /></text>
                    <text class="value">$ {{ item.repayAmount }}</text>
                  </view>
                  <view class="item">
                    <text class="label"><rich-text :nodes="item.titleDate" /></text>
                    <text class="value">{{ item.repayDate }}</text>
                  </view>
                </view>
              </view>
            </view>
          </view>
          <text class="msg"> Su solicitud de préstamo ha sido enviada con éxito.</text>
        </view>

        <view class="close-wrapper">
          <image
            @click="closeApplyLoanModal"
            class="close"
            src="/static/apply-success-close-icon.png"
          />
          <text class="count-down"> {{ countDown }}S</text>
        </view>
      </view>
    </uni-popup>
  </view>
</template>
<script>
import StatusBar from '../../components/StatusBar/index.vue';
export default {
  data() {
    return {
      hasStatusBar: false,
      isCheckAgreement: true, // 是否选中协议
      isScroll: false,
      detail: {},
      currentPeriodsDetailId: null,
      timer: null,
      countDown: 3,

      showSelectMoneyModal: false,
      selectMoneyList: [0], // 选中的金额  默认最大金额的下标
      tipsData: {},
      installmentData: {},
      contractList: [],
    };
  },
  computed: {
    agreementList() {
      return [
        {
          label: 'Contrato del préstamo',
          link: 'https://temp.prestamogratis.com/platapuntuals/privacy.html',
        },
        ...this.contractList,
      ];
    },
    selectMoney() {
      return this.moneyList[this.selectMoneyList[0]] || '';
    },
    periodsList() {
      return this.detail?.proDetailList || [];
    },
    currentPeriods() {
      if (!this.currentPeriodsDetailId || !this.periodsList.length) return null;
      return this.periodsList.find((item) => item.detailId === this.currentPeriodsDetailId);
    },
    combiendMoneyCurrentPeriods() {
      return this.selectMoney + this.currentPeriods?.detailId;
    },
    statusBarHeight() {
      return 44;
    },
    moneyList() {
      if (this.periodsList.length === 0) return [];
      /* if (!this.currentPeriods) {
        const max = this.periodsList[0].maxCreditAmount;
        return max ? [max] : [];
      } */
      const { maxCreditAmount, minCreditAmount, incrAmount } = this.currentPeriods;
      let amount = maxCreditAmount;
      const list = [];
      while (amount > minCreditAmount) {
        list.push(amount);
        amount -= incrAmount;
      }
      if (amount <= minCreditAmount) {
        list.push(amount);
      }
      return list;
    },
    periodsDetailList() {
      if (!Object.keys(this.installmentData).length) return [];
      return [
        {
          label: 'Monto total del pago',
          value: `$ ${this.installmentData?.preAmount}`,
          isBold: true,
        },
        {
          label: 'Monto del préstamo',
          value: `$ ${this.installmentData?.serverApplyAmount}`,
          isBold: false,
        },
        {
          label: 'Interés',
          value: `$ ${this.installmentData?.intAmount}`,
          isBold: false,
        },
        {
          label: 'Gasto de servicio',
          value: `$ ${this.installmentData?.serviceFee}`,
          isBold: false,
        },
        {
          label: 'Gasto de impuesto（IVA）',
          value: `$ ${this.installmentData?.iva}`,
          isBold: false,
        },
        ...this.installmentData.ext.map((item) => ({
          label: item.name,
          value: `$ ${item.amount}`,
          isBold: false,
        })),
        {
          label: 'Monto recibido',
          value: `$ ${this.installmentData?.disbursalAmount}`,
          isBold: true,
        },
      ];
    },
    resultMapPlanList() {
      return this.installmentData?.resultMapPlanList || [];
    },
    userInfo() {
      return this.$getUserInfo();
    },
  },
  components: { StatusBar },
  onLoad(e) {
    this.hasStatusBar = !!e?.hasStatusBar;
    this.handleGetData();
  },

  methods: {
    async handleGetAgreement() {
      if (!this.currentPeriods || !this.selectMoney) return;
      try {
        const result = await this.$request('/lastKnowledge/saluteReasonableExit', {
          briefCurtainProudTowel: this.selectMoney,
          brokenMatterPianist: this.currentPeriods.detailId,
          merryFollowingMiddle: this.userInfo.userId,
          brightRobotRainyCanadianPercentage: 0,
        });
        this.contractList = result.map((item) => ({
          label: item.hugeVocabularyHot,
          link: item.smallHeroineStraightBeach,
        }));
        console.log('result', result);
      } catch (e) {
        console.log(e);
      }
    },
    handleClickHref(item) {
      window.location.href = item.link;
    },
    async handleApply() {
      if (!this.isCheckAgreement) {
        uni.showToast({
          title: 'Primero marque el acuerdo',
          icon: 'error',
          mask: true,
        });
        return;
      }
      if (!this.currentPeriodsDetailId) {
        uni.showToast({
          title: 'Seleccione el plazo del préstamo',
          icon: 'error',
          mask: true,
        });
        return;
      }
      try {
        console.log('this.currentPeriods', this.currentPeriods);
        const { detailId } = this.currentPeriods;
        const result = await this.$request('/mixture/rudeUserPear', {
          youngBalconyUnimportantTastyFood: this.detail.productId,
          brokenMatterPianist: detailId,
          briefCurtainProudTowel: this.selectMoney,
        });
        console.log('result', result);
        this.applySuccess();
      } catch (e) {
        console.log(e);
      }
    },
    countDownFn() {
      if (this.timer) {
        clearInterval(this.timer);
      }
      this.countDown = 3;
      this.timer = setInterval(() => {
        this.countDown--;
        console.log('this.countDown', this.countDown);
        if (this.countDown === 0) {
          this.closeApplyLoanModal();
          clearInterval(this.timer);
        }
      }, 1000);
    },
    async handleGetTipsData() {
      if (!this.periodsList.length) return;
      const orderType = !this.currentPeriods || +this.currentPeriods?.periodDuration === 1 ? 0 : 1;
      const detail = this.currentPeriods ? this.currentPeriods : this.periodsList[0];

      try {
        const result = await this.$request('/spanishFeeling/doesConvenientKilo', {
          brightRobotRainyCanadianPercentage: orderType,
          brokenMatterPianist: detail.detailId,
          briefCurtainProudTowel: this.selectMoney,
        });

        const {
          magicAnybody: maxApplyAmt,
          safePorridgeFeelingTiredLaundry: maxApplyDuration,
          sharpUnderstandingExtraordinaryDevotion: minServiceFee,
        } = result;
        this.$set(this.tipsData, 'maxApplyAmt', maxApplyAmt);
        this.$set(this.tipsData, 'maxApplyDuration', maxApplyDuration);
        this.$set(this.tipsData, 'minServiceFee', minServiceFee);
      } catch (e) {
        console.log(e);
      }
    },
    handleSelectPeriods(data) {
      if (data.disabled || this.currentPeriodsDetailId === data.detailId) return;
      this.currentPeriodsDetailId = data.detailId;
      this.$set(this.selectMoneyList, 0, 0);
      this.handleGetTipsData();
      this.handleGetInstallmentData();
    },
    transferData(data) {
      if (!data) {
        this.detail({});
        return;
      }
      const {
        youngBalconyUnimportantTastyFood: productId,
        festivalLoudspeakerSadShooting: proDetailList,
      } = data;
      const list = proDetailList?.map((item, index) => ({
        duration: item.sharpArabCameraChat,
        detailId: item.brokenMatterPianist,
        incrAmount: item.fancySnackInstruction,
        maxCreditAmount: item.foreignPossibilityHarmfulSecondAirplane,
        minCreditAmount: item.naturalPaperSteadyPlatformContraryPride,
        periodDuration: item.quickLoudGreedySoutheast,
        disabled: index === proDetailList.length - 1 || index === proDetailList.length - 2,
      }));
      console.log('list', list);

      this.$set(this.detail, 'productId', productId);
      this.$set(this.detail, 'proDetailList', list);
      if (list.length === 3) {
        this.currentPeriodsDetailId = list[0].detailId;
        this.handleGetInstallmentData();
      }
    },
    async handleGetData() {
      try {
        const result = await this.$request('/mixture/repeatFullMay');
        console.log('result', result);
        this.transferData(result);
        this.handleGetTipsData();
      } catch (e) {
        console.log(e);
      }
    },
    handleSelectMoneyChange(value) {
      if (this.selectMoneyList[0] === value) return;
      this.$set(this.selectMoneyList, 0, value);
    },
    applySuccess() {
      this.$refs.popup.open();
      this.countDownFn();
    },
    closeApplyLoanModal() {
      this.$refs.popup.close();
    },
    _insertStr(str) {
      if (!str) return str;
      return `<span style="color:#E02020;font-weight:500">${str}</span>`;
    },
    installmentDataTransfer(data) {
      const map = {
        activeSoundFemaleParent: 'preAmount',
        mobileEmptyDayKangaroo: 'disbursalAmount',
        delightedDampFlamingAutumn: 'serverApplyAmount',
        ashamedBowlFrogFavouriteCow: 'serviceFee',
        looseGrandPrimaryDryer: 'iva',
        properZooFirmAnxiousTape: 'intAmount',
        littleNarrowViewDelight: 'afterCouponRepayAmount',
        asianIncident: 'couponEndDate',
        dirtyLegMassReasonableDay: 'paymentDate',
        handsomeNaturalMapleAntarcticAward: 'repayDate',
        politeTypewriterSillyAnythingPrivateConcert: 'couponBannerDesc',
        passiveTaxMile: 'couponRateDesc',
        mainBakeryMoment: 'curDuration',
        entireLazyHappyTravel: 'ext',
        hugeVocabularyHot: 'name',
        russianSafeEarthquake: 'totalPeriod',
        preciousThe: 'amount',
        rectangleMenuPath: 'titleDate',
        familiarPeachDistantYours: 'titleAmount',
        beautifulBirthdayFoggyMoviePension: 'titleDateRedMap',
        neatGlasshouseMildCoursebook: 'titleAmountRedMap',
        longArabUserFunnyLung: 'resultMapPlanList',
        handsomeNaturalMapleAntarcticAward: 'repayDate',
        racialCloud: 'serviceFeeRate',
        englishNumberClothes: 'repayAmount',
        finalSideClassDiscovery: 'loanAmount',
        manAsianSurface: 'otherFee',
        metalNoisyTypistMistakenLake: 'totalOtherFee',
        mainMushroomCheer: 'technologyFee',
        changeableStayChiefLonelyBean: 'creditFee',
        unfortunatePortRecentNotebookFingernail: 'taxFixed',
        sharpArabCameraChat: 'duration',
        spiritualMountainHamUniversity: 'beforeIniFee',
        pleasedAttractiveTastelessBase: 'couponAmount',
        activeSoundFemaleParent: 'preAmount',
        mobileEmptyDayKangaroo: 'disbursalAmount',
        delightedDampFlamingAutumn: 'serverApplyAmount',
        ashamedBowlFrogFavouriteCow: 'serviceFee',
        properZooFirmAnxiousTape: 'intAmount',
        littleNarrowViewDelight: 'afterCouponRepayAmount',
        asianIncident: 'couponEndDate',
        dirtyLegMassReasonableDay: 'paymentDate',
        handsomeNaturalMapleAntarcticAward: 'repayDate',
        politeTypewriterSillyAnythingPrivateConcert: 'couponBannerDesc',
        passiveTaxMile: 'couponRateDesc',
        swissDeerSteepSurgeon: 'taxFee',
        englishNumberClothes: 'repayAmount',
        publicUnionThoseChairman: 'beforeServiceFee',
        femaleStandDullGrapeLab: 'orderFees',
        unimportantBuddhismNorthernPeacefulMillion: 'id',
        goldenTractorJewelryBottle: 'apr',
        uglyCoastUsualHostessRapidDevotion: 'titlePeriod',
        freshRealIrishPlayground: 'titlePeriodRedMap',
        preciousThe: 'amount',
        muchTheirNorthFingernail: 'feeName',
        indianMovieCartoon: 'interestAmount',
        mobileEmptyDayKangaroo: 'disbursalAmount',
        tightStringBuddhism: 'orderFeeDetail',
        leftNorthSlipCruelSchoolmate: 'fee',
        duePeasantDollarHoliday: 'beforeDeFee',
        ashamedBowlFrogFavouriteCow: 'serviceFee',
        triangleNervousBeginning: 'overdueRate',
        earlyNearCeilingTastyFlour: 'overdueAmount',
        spareMoneyUndergroundTank: 'feeStatus',
      };
      for (const key in map) {
        if (key === 'longArabUserFunnyLung') {
          this.$set(
            this.installmentData,
            map[key],
            data[key].map((item) => {
              const data = {};
              for (const key in item) {
                data[map[key]] = item[key];
              }
              for (const key in data.titleAmountRedMap) {
                data.titleAmount = data.titleAmount.replace(
                  key,
                  this._insertStr(data.titleAmountRedMap[key])
                );
              }
              for (const key in data.titleDateRedMap) {
                data.titleDate = data.titleDate.replace(
                  key,
                  this._insertStr(data.titleDateRedMap[key])
                );
              }
              for (const key in data.titlePeriodRedMap) {
                data.titlePeriod = data.titlePeriod.replace(
                  key,
                  this._insertStr(data.titlePeriodRedMap[key])
                );
              }
              data.titleAmount = data.titleAmount.replace(/  +/g, ' ').trim();
              data.titleDate = data.titleDate.replace(/  +/g, ' ').trim();
              data.titlePeriod = data.titlePeriod.replace(/  +/g, ' ').trim();
              return data;
            })
          );
        } else {
          this.$set(this.installmentData, map[key], data[key]);
        }
      }
      console.log('this.installmentData', this.installmentData);
    },
    async handleGetInstallmentData() {
      try {
        if (this.periodsList.length < 3 || !this.currentPeriodsDetailId) return;
        const detail = this.currentPeriods ? this.currentPeriods : this.periodsList[0];
        const result = await this.$request('/mixture/manyCompositionElectricity', {
          youngBalconyUnimportantTastyFood: this.detail.productId,
          brokenMatterPianist: detail.detailId,
          briefCurtainProudTowel: this.selectMoney,
        });
        this.installmentDataTransfer(result);
      } catch (e) {
        console.log(e);
      }
    },
  },
  watch: {
    showSelectMoneyModal(v) {
      if (!v) {
        this.handleGetInstallmentData();
        this.handleGetTipsData();
      }
    },
    // 判断 currentPeriodsDetailId 和 selectMoney 变化监听
    combiendMoneyCurrentPeriods(v) {
      this.handleGetAgreement();
    },
  },
  onPageScroll(e) {
    this.isScroll = e.scrollTop > this.statusBarHeight;
  },
};
</script>
<style lang="scss" scoped>
.apply-loan-wrapper {
  min-height: 100vh;
  background: #f2f2f2;
  .top-card {
    background: #24443b;
    margin-bottom: 20px;
    .card-container {
      box-sizing: border-box;
      padding: 6px 20px 17px;
      .select-money-wrapper {
        position: relative;
        box-sizing: border-box;
        padding: 12px;
        width: 100%;
        border-radius: 8px;
        background: #edffea;
        margin-bottom: 10px;
        .label {
          display: block;
          font-size: 15px;
          line-height: 17px;
          color: #333;
          padding-left: 10px;
          margin-bottom: 11px;
        }
        .select-money {
          position: relative;
          display: flex;
          flex-direction: row;
          box-sizing: border-box;
          padding: 0 10px;
          height: 54px;
          border-radius: 8px;
          background: #9fe294;
          align-items: center;
          justify-content: space-between;
          .money {
            font-size: 26px;
            font-weight: bold;
            color: #2f4d45;
          }
          .select-money-icon {
            width: 12px;
            height: 22px;
          }
        }
        .select-money-modal {
          position: absolute;
          left: 50%;
          top: 100%;
          width: calc(100% - 44px);
          transform: translateX(-50%);
          background: #fff;
          .only {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 52px;
            font-size: 18px;
            font-weight: bold;
            color: #2f4d45;
          }
        }
      }
      .next-loan-wrapper {
        display: flex;
        flex-direction: row;
        align-items: center;
        gap: 6px;
        .text {
          flex: 1;
          font-size: 12px;
          line-height: 14px;
          color: #ffdf3f;
          .bold {
            color: #ff3f3f;
          }
        }
        .image {
          width: 39px;
          height: 36px;
        }
      }
    }
  }
  .apply-loan-container {
    display: flex;
    flex-direction: column;
    width: 100%;
    gap: 20px;
    padding-bottom: 12px;
  }
  .select-periods-wrapper {
    box-sizing: border-box;
    padding: 0 21px;
    display: flex;
    flex-direction: column;
    .title {
      color: #16271e;
      font-size: 18px;
      line-height: 21px;
      font-weight: bold;
      margin-bottom: 13px;
    }
    .periods-list {
      display: grid;
      // 三列两行，行间距12px，列间距17px
      grid-template-columns: repeat(3, 1fr);
      gap: 12px 17px;
      .periods-item {
        position: relative;
        height: 48px;
        box-sizing: border-box;
        border-radius: 8px;
        background: #d3ffcc;
        border: 1px solid rgba(29, 62, 53, 0.15);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        .periods-disabled-icon {
          position: absolute;
          left: 50%;
          top: 50%;
          width: 16px;
          height: 20px;
          transform: translate(-50%, -50%);
        }
        &.active {
          background-color: #74f461;
          border-color: #74f461;
        }
        &.disabled {
          background-color: #d6d6d6;
          border-color: #d6d6d6;
          .day,
          .period {
            color: #6d7772;
          }
        }
        .day {
          font-size: 14px;
          font-weight: bold;
          color: #1d3e35;
        }
        .multi {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          height: 100%;
          .period {
            font-size: 16px;
            font-weight: bold;
            color: #6d7772;
            line-height: 16px;
          }
          .day {
            font-size: 14px;
            color: #6d7772;
            line-height: 16px;
          }
        }
      }
    }
    .multi-tip {
      padding-top: 11px;
      padding-left: 15px;
      padding-right: 8px;
      margin-top: 15px;
      display: inline-block;
      background: #fff9f4;
      min-height: 36px;
      border-radius: 8px;
      .text {
        font-size: 14px;
        line-height: 16px;
        color: #fa6400;
        .bold {
          font-weight: bold;
          color: #fa0000;
          margin: 0 8px;
        }
      }
    }
  }
  .plan-wrapper {
    .plan-container {
      background: #fff;
      box-sizing: border-box;
      padding: 18px 20px;
      .title {
        display: block;
        padding-left: 9px;
        font-size: 18px;
        line-height: 20px;
        color: #333;
        font-weight: bold;
        margin-bottom: 10px;
      }
      .one {
        padding-top: 18px;
        padding-bottom: 16px;
        background: #f0f9ee;
        border-radius: 8px;
      }
      .multi-list {
        display: flex;
        flex-direction: column;
        gap: 10px;
        width: 100%;
        .list-item {
          box-sizing: border-box;
          padding: 11px 20px 13px;
          background: #f0f9ee;
          border-radius: 8px;
          display: flex;
          flex-direction: column;
          .top {
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 5px;
            .icon {
              width: 16px;
              height: 18px;
            }
            .step {
              font-size: 16px;
              line-height: 22px;
              color: #333;
              font-weight: bold;
            }
          }
          .list {
            .item {
              padding: 0;
            }
          }
        }
      }
      .list {
        display: flex;
        flex-direction: column;
        width: 100%;
        gap: 12px;
        .item {
          box-sizing: border-box;
          padding: 0 20px;
          width: 100%;
          display: flex;
          justify-content: space-between;
          gap: 10px;
          .label {
            flex: 1;
            font-size: 14px;
            line-height: 16px;
            color: #666666;
            .bold {
              margin: 0 8px;
              color: #e02020;
            }
          }
          .value {
            font-size: 14px;
            font-weight: bold;
            color: #333333;
          }
        }
      }
    }
  }
  .periods-detail {
    box-sizing: border-box;
    padding: 15px 30px 20px;
    background: #fff;
    .periods-detail-title {
      display: block;
      width: 100%;
      font-size: 18px;
      font-weight: bold;
      line-height: 20px;
      text-align: center;
      padding-bottom: 7px;
      border-bottom: 1px solid #eef2ff;
      margin-bottom: 13px;
    }
    .list {
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      gap: 13px;
      .item {
        display: flex;
        flex-direction: row;
        width: 100%;
        justify-content: space-between;
        color: rgba($color: #000000, $alpha: 0.5);
        font-size: 14px;
        line-height: 17px;
        &.bold {
          color: #000;
          font-weight: bold;
        }
      }
    }
  }
  .apply-wrapper {
    box-sizing: border-box;
    padding: 40px 24px 11px;
    display: flex;
    flex-direction: column;
    .btn {
      position: relative;
      width: 100%;
      height: 50px;
      background: #1d3e35;
      border: 1px solid #74f461;
      border-radius: 4px;
      font-size: 18px;
      font-weight: bold;
      color: #fff;
      margin-bottom: 14px;
      .btn-wrapper {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .tips {
        box-sizing: border-box;
        padding: 8px 21px 6px 17px;
        border-radius: 6px;
        background: #ffe376;
        position: absolute;
        width: 100%;
        top: -100%;
        left: 0;
        line-height: 14px;
        .text {
          font-size: 12px;
          color: #333333;
          &.bold {
            margin: 0 6px;
            color: #ff0000;
          }
        }
        .triangle {
          position: absolute;
          bottom: -7px;
          left: 50%;
          width: 0;
          height: 0;
          border-left: 4.5px solid transparent;
          border-right: 4.5px solid transparent;
          border-top: 6px solid #ffe376;
          transform: translateX(-50%);
        }
      }
    }
    .agreement {
      display: flex;
      flex-direction: row;
      gap: 3px;
      .checkbox {
        width: 20px;
        height: 20px;
      }
      .text {
        flex: 1;
        font-size: 12px;
        line-height: 14px;
        color: #666666;
        .link {
          color: #427768;
        }
      }
    }
  }
  .mask {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 99;
  }
}
.money-picker-view-wrapper {
  position: relative;
  height: 192px;
  .bottom-mask {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 23px;
    background: linear-gradient(180deg, rgba(36, 66, 58, 0) 0%, #0f2b24 100%);
    opacity: 0.31;
  }
}
/deep/.money-picker-view {
  height: 192px;
  .money-picker-item {
    display: flex;
    width: 100%;
    justify-content: center;
    align-items: center;
    height: 38px;
    border-bottom: 1px dashed #e6e6e6;
    font-size: 18px;
    color: #999999;
    &.active {
      font-size: 18px;
      font-weight: bold;
      color: #2f4d45;
    }
  }
  .money-picker-indicator {
    height: 38px;

    &::after,
    &::before {
      display: none;
    }
  }
  .uni-picker-view-content {
    box-sizing: border-box;
    padding-left: 10px !important;
    padding-right: 10px !important;
  }
}
/deep/.apply-loan-modal {
  position: relative;
  width: 350px;
  box-sizing: border-box;
  padding: 19px 8px 16px;
  background: #fff;
  border-radius: 8px;
  .apply-loan-modal-content {
    max-height: 456px;
    overflow-y: auto;
    .list {
      width: 100%;
      display: flex;
      flex-direction: column;
      gap: 10px;
      .item {
        display: flex;
        width: 100%;
        justify-content: space-between;
        .label,
        .value {
          font-size: 15px;
          line-height: 17px;
          color: #333333;
        }
        .value {
          font-weight: bold;
        }
      }
    }
    .info {
      box-sizing: border-box;
      border-radius: 8px;
      background: #f0f9ee;
      padding: 11px 23px 13px 15px;
      margin-bottom: 17px;
    }
    .periods-wrapper {
      box-sizing: border-box;
      padding: 20px 9px 16px;
      border-radius: 8px;
      background: #f0f9ee;
      margin-bottom: 10px;
      .title {
        box-sizing: border-box;
        display: block;
        padding-left: 6px;
        font-size: 18px;
        line-height: 21px;
        color: #333333;
        font-weight: bold;
        margin-bottom: 10px;
      }
      .only {
        box-sizing: border-box;
        padding: 18px 10px;
        background: #ffffff;
        border-radius: 8px;
      }
      .list {
        gap: 12px;
        .item {
          .label,
          .value {
            color: #666666;
            font-size: 14px;
            line-height: 16px;
            .bold {
              color: #e02020;
              margin: 0 8px;
            }
          }
          .value {
            color: #333;
          }
        }
      }
      .multi {
        display: flex;
        flex-direction: column;
        gap: 10px;
        .multi-item {
          box-sizing: border-box;
          padding: 9px 10px 13px;
          background: #fff;
          border-radius: 8px;
          .multi-item-top {
            display: flex;
            flex-direction: row;
            width: 100%;
            gap: 6px;
            margin-bottom: 8px;
            .icon {
              width: 16px;
              height: 17px;
            }
            .text {
              font-size: 16px;
              font-weight: bold;
              line-height: 18px;
              color: #333333;
            }
          }
        }
      }
    }
    .msg {
      display: block;
      box-sizing: border-box;
      padding: 7px 13px 17px;
      background: #f0ffeb;
      border-radius: 8px;
      font-size: 15px;
      line-height: 17px;
      text-align: center;
      color: #666666;
      margin-top: 10px;
    }
  }
  .close-wrapper {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    bottom: -77px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 9px;
    .close {
      width: 38px;
      height: 39px;
    }
    .count-down {
      font-size: 15px;
      color: #fff;
    }
  }
}
</style>
