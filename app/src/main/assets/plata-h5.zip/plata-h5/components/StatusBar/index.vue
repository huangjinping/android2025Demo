<template>
  <view class="status-bar-wrapper">
    <view class="status-bar" :style="statysBarStyle">
      <image v-if="hasBack" class="back" src="/static/back-icon.png" @click="handleBack" />
      <text class="title">{{ title }}</text>
      <image class="service" src="/static/service-icon.png" @click="handleService" />
    </view>
    <view v-if="hasPlaceholder" class="placeholder"></view>
  </view>
</template>
<script>
export default {
  props: {
    title: {
      type: String,
      default: '',
    },
    hasService: {
      type: Boolean,
      default: false,
    },
    hasPlaceholder: {
      type: Boolean,
      default: false,
    },
    hasBack: {
      type: Boolean,
      default: false,
    },
    isScroll: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {};
  },
  computed: {
    statysBarStyle() {
      return {
        background: this.isScroll ? 'rgba(0,0,0,0.5)' : 'transparent',
      };
    },
  },

  methods: {
    handleBack() {
      uni.navigateBack();
    },
    handleService() {
      const pages = getCurrentPages();
      // 获取当前页面实例
      const currentPage = pages[pages.length - 1];
      const frontSource = currentPage?.route || '';
      const { userId } = this.$getUserInfo();
      window.location.href = `https://temp.prestamogratis.com/customer/index.html?frontSource=${frontSource}&appSsid=466&userId=${userId}&mobile=test`;
    },
  },
};
</script>
<style scoped lang="scss">
.status-bar-wrapper {
  .status-bar {
    position: fixed;
    top: 0;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 44px;
    z-index: 999;
    .back {
      position: absolute;
      top: 50%;
      left: 20px;
      transform: translateY(-50%);
      width: 19px;
      height: 18px;
    }
    .title {
      font-size: 15px;
      line-height: 17px;
      color: #fff;
    }
    .service {
      position: absolute;
      top: 50%;
      right: 20px;
      transform: translateY(-50%);
      width: 22px;
      height: 18px;
    }
  }
  .placeholder {
    width: 100%;
    height: 44px;
  }
}
</style>
